import time
import requests
import random
import logging
from scapy.all import sniff, IP, TCP, UDP, conf

API_URL = "http://127.0.0.1:5000/predict"

conf.verb = 0 
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

print("=============================================")
print("    LIVE WIFI SNIFFER ACTIVATED           ")
print("=============================================")
print("Status: Connected to Network Driver (Npcap)")
print("Action: Surf the web to see live data...")
print("=============================================")

def process_packet(packet):
    try:
        if IP in packet:
            src_ip = packet[IP].src
            dst_ip = packet[IP].dst
            pkt_len = packet[IP].len
            
            real_bytes = pkt_len
            
            traffic_count = 1
            if real_bytes > 1200:
                traffic_count = random.randint(30, 80) 
            else:
                traffic_count = random.randint(1, 10)  

            features = [0] * 42
            
            features[0] = 0             
            features[4] = real_bytes    
            features[22] = traffic_count 
            
            print(f"📡 SCANNING: {src_ip} -> {dst_ip} | Size: {real_bytes} Bytes")

            try:
                requests.post(API_URL, json={'features': features}, timeout=0.05)
            except:
                pass 

    except Exception as e:
        pass

try:
    sniff(filter="ip", prn=process_packet, store=0)
except Exception as e:
    print(f"\n ERROR: {e}")
    print("TIP: Try running VS Code as Administrator.")